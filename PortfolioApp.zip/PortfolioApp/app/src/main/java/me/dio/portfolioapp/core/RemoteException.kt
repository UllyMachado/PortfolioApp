package me.dio.portfolioapp.core

class RemoteException(override val message: String) : Throwable()